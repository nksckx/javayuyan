import java.util.Date;
import java.util.ArrayList;
import java.util.Random;

class SaleCD
{
	int cdid;
	String name;
	int count;
	public SaleCD(int cdid, String name, int count) {
		super();
		this.cdid = cdid;
		this.name = name;
		this.count = count;
	}
	@Override
	public String toString() {
		return "SaleCD [cdid=" + cdid + ", name=" + name + ", count=" + count
				+ "]";
	}
	
	
}
class RentCD
{
	int cdid;
	String name;
	boolean isRent;
	public RentCD(int cdid, String name, boolean isRent) {
		super();
		this.cdid = cdid;
		this.name = name;
		this.isRent = isRent;
	}

}
class GetInThread extends Thread{
	CDShop cs;

	public GetInThread(CDShop cs) {
		super();
		this.cs = cs;
		this.start();
	}
	public void run() 
	{
		synchronized(cs.SaleList){
			while(true){
			cs.getIn();	
			cs.SaleList.notify();
			System.out.println("GETIN"+new Date());
			try {
				cs.SaleList.wait(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
		
	}
	
}
class SaleThread extends Thread{
	CDShop cs;

	public SaleThread(CDShop cs) {
		super();
		this.cs = cs;
		try {
			Thread.sleep(new Random().nextInt(50));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.start();
	}
	public void run() 
	{
		while (true){
		int count=new Random().nextInt(5)+1;
		int cdid=new Random().nextInt(5)+1;
		synchronized(cs.SaleList){
			if (cs.saleCD(cdid, count))
			{
				System.out.println("Sale id="+cdid+"count="+count+new Date());
				System.out.println(cs.SaleList);
			}
			else
			{
				System.out.println(cs.SaleList);
				System.out.println("Sale id="+cdid+"count="+count+"��������!");
				cs.SaleList.notifyAll();
				if(new Random().nextBoolean())
				{
					try {
						cs.SaleList.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (cs.saleCD(cdid, count))
					{
						System.out.println("After WaitSale id="+cdid+"count="+count+new Date());
					}
				}
				
			}
			
		}
		try {
			Thread.sleep(new Random().nextInt(500));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}
}
class ControlThread extends Thread{
	CDShop cs;

	public ControlThread(CDShop cs) {
		super();
		this.cs = cs;
	}
	public void run()
	{
		
		GetInThread gt=new GetInThread(cs);
		
		
		SaleThread st=new SaleThread(cs);
		st=new SaleThread(cs);
		st=new SaleThread(cs);
		st=new SaleThread(cs);
	}
}
public class CDShop {
	ArrayList<RentCD> RentList =new ArrayList<RentCD>();
	ArrayList<SaleCD> SaleList =new ArrayList<SaleCD>();
	public CDShop() {
		RentList.add(new RentCD(1,"rentcd1",false));
		RentList.add(new RentCD(2,"rentcd2",false));
		RentList.add(new RentCD(3,"rentcd3",false));
		RentList.add(new RentCD(4,"rentcd4",false));
		RentList.add(new RentCD(5,"rentcd5",false));
		SaleList.add(new SaleCD(1,"SaleCd1",10));
		SaleList.add(new SaleCD(2,"SaleCd2",10));
		SaleList.add(new SaleCD(3,"SaleCd3",10));
		SaleList.add(new SaleCD(4,"SaleCd4",10));
		SaleList.add(new SaleCD(5,"SaleCd5",10));		
		
	}
public void getIn()
{
	synchronized(SaleList){
	for(int i=0;i<SaleList.size();i++)
	{
		SaleList.get(i).count=10;
	}
	System.out.println("GETIN in CDSHop"+SaleList);
	}
	//
}
public boolean saleCD(int cdid,int count)
{
	for(int i=0;i<this.SaleList.size();i++)
	{
		if (SaleList.get(i).cdid==cdid)
		{
			SaleCD c=SaleList.get(i);
			if (c.count<count)
				return false;
			else
			{
				c.count=c.count-count;
				return true;
			}
			
		}
	}
	return true;
	
}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CDShop cd=new CDShop();
		System.out.println("before sale"+cd.SaleList);
		ControlThread ct=new ControlThread(cd);
		ct.setDaemon(true);
		ct.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
