
public class CDshop {
    public static void main(String[] args) { 
        
        int[] goods = new int[11];
        boolean[] showing = new boolean[11];
        long start=System.currentTimeMillis();
        for(int i=1;i<=10;i++)
        {
            goods[i]=10;
            showing[i]=true;
        }
        
        System.out.println("两分钟内一个进货线程、五个购买线程、五个租借线程");
        
        Fill f = new Fill(goods,start);
        Buy b1 = new Buy(goods,start);
        Buy b2 = new Buy(goods,start);
        Buy b3 = new Buy(goods,start);
        Buy b4 = new Buy(goods,start);
        Buy b5 = new Buy(goods,start);
        Rent r1 = new Rent(showing,start);
        Rent r2 = new Rent(showing,start);
        Rent r3 = new Rent(showing,start);
        Rent r4 = new Rent(showing,start);
        Rent r5 = new Rent(showing,start);
        f.start();
        b1.start();
        b2.start();
        b3.start();
        b4.start();
        b5.start();
    /*  r1.start();
        r2.start();
        r3.start();
        r4.start();
        r5.start();
    */   
    }
    
    static class Fill extends Thread{
        private int[] goods;
        private long start;
        Fill(int[] goods,long start) {
            this.goods = goods;
            this.start = start;
        }
        @Override public void run() {
            synchronized(goods){
            while(System.currentTimeMillis()-start<120000){
                try {
                    Thread.sleep(1000);
                    long end=System.currentTimeMillis();
                    for(int i=1;i<=10;i++)
                        goods[i]=10;
                    System.out.println();
                    System.out.println(end-start+"已按时进货，完成所有出售CD的数量填充");
                    System.out.println();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        }
    }
 
    static class Buy extends Thread{
        private int[] goods;
        private long start;
        Buy(int[] goods,long start) {
            this.goods = goods;
            this.start = start;
        }
        @Override public void run() {
            synchronized(goods){
            while(System.currentTimeMillis()-start<120000){
                try {
                    int time = (int)(Math.random()*200+1);
                    Thread.sleep(time);
         
                    int number = (int)(Math.random()*5+1);
                    long end=System.currentTimeMillis();
                    System.out.println();
                    System.out.println(end-start+"ms进店的顾客开始交易");
                    for(int i=1;i<=number;i++)
                    {
                        int kind = (int)(Math.random()*10+1);
                        if(goods[kind]>0)
                        {
                            goods[kind]--;
                            System.out.println(end-start+"ms进店的顾客购买了一张"+kind+"号光碟;"+kind+"号光碟还剩"+goods[kind]+"张。已购买了"+i+"张。");
                        }
                        else
                        {
                            boolean is_wait = Math.random()>=0.5;
                            System.out.println("(°_°) 糟糕!"+(end-start)+"ms进店的顾客想要"+kind+"号光碟;却发现没货。");
                            if(is_wait)
                            {
                                System.out.println("(=_=) 顾客表示可以耐心的等待一下下。");
                                System.out.println("(O_o) 通知紧急进货！！！");
                                
                                for(int ii=1;ii<=10;ii++)
                                    goods[ii]=10;
                                System.out.println("(￣▽￣) 已为顾客紧急进货，完成所有出售CD的数量填充");
                                goods[kind]--;
                                System.out.println(end-start+"ms进店的顾客等到了进货");
                                System.out.println("(^_^) 他开心的购买了一张"+kind+"号光碟;"+kind+"号光碟还剩"+goods[kind]+"张。已购买了"+i+"张。");
                            }
                            else
                            {   System.out.println("(♯｀∧´) "+(end-start)+"ms进店的顾客拒绝等待并且愤怒的离去"); 
                                break;
                            }
                        }
                    }
                    System.out.println(end-start+"ms进店的顾客交易完毕");
                    System.out.println();
                } catch (InterruptedException e) {
                    e.printStackTrace();}}}}}
 
    static class Rent extends Thread{
        private boolean[] showing;
        private long start;
        Rent(boolean[] showing,long start) {
            this.showing = showing;
            this.start = start;
        }
        @Override public void run() {
            synchronized(showing){
            while (System.currentTimeMillis()-start<120000){
                try {
                    int time = (int)(Math.random()*200+1);
                    Thread.sleep(time);
                    
                    long end=System.currentTimeMillis();
                    int number = (int)(Math.random()*10+1);
                    if(showing[number])
                    {
                        System.out.println();
                        System.out.println(end-start+"ms进店的顾客租借立即得到的"+number+"号CD。");
                        showing[number] = false;
                        time = (int)(Math.random()*101+200);
                        showing.wait(time);
                        showing[number] = true;
                        System.out.println(end-start+"ms进店的顾客归还立即得到的"+number+"号CD。");
                        System.out.println();
                        showing.notifyAll();
                    }
                    else
                    {
                       boolean is_wait = Math.random()>=0.5;
                       System.out.println("_(´ཀ`」 ∠)_  "+(end-start)+"ms进店的顾客想要租借"+number+"号CD，却发现已被人借走");
                       if(is_wait)
                       {
                           System.out.println("(T_T) "+(end-start)+"ms进店的顾客表示可以耐心的等一小下");
                           showing.wait();
                           System.out.println("(^o^) "+(end-start)+"ms进店的顾客通过等待租借到的"+number+"号CD。");
                        showing[number] = false;
                        time = (int)(Math.random()*101+200);
                        showing.wait(time);
                        showing[number] = true;
                        System.out.println("(^ω^)"+(end-start)+"ms进店的顾客归还通过等待租借到的"+number+"号CD。");
                        System.out.println();
                        showing.notifyAll();
                       }
                       else
                       {
                        System.out.println("(╯‵□′)╯︵┻━┻ "+(end-start)+"ms进店的顾客拒绝等待并且伤心欲绝的离开时顺手掀翻了桌子"); 
                        System.out.println();
                       }
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }}}}}}