package concur;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

class CDSale{
	int ID;
	String cdName;
	int num;
	synchronized public boolean sale(int i) {
		if(num<i)
			System.out.println((new Date())+"sale cdid=" + ID+" sale num"+i +" remain num "+num);
		while(num<i) {			
			notifyAll();
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		this.num=num-i;
		System.out.println((new Date())+"sale cdid=" + ID+" num"+i);
		return true;
	}
	synchronized public void getin() {
		num=10;
		System.out.println((new Date())+"input cdid=" + ID+" num"+10);

		notifyAll();
		try {
			wait(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CDSale other = (CDSale) obj;
		if (ID != other.ID)
			return false;
		return true;
	}

	
}
class InputThread extends Thread{
	CDManager cdm;
	
	public InputThread(CDManager cdm) {
		super();
		this.cdm = cdm;
		this.setDaemon(true);
	}

	public void run() {
		while(true) {
			cdm.input();
		}
	}
}
class SaleThread extends Thread{
	CDManager cdm;
	
	public SaleThread(CDManager cdm) {
		super();
		this.cdm = cdm;
		this.setDaemon(true);
	}

	public void run() {
		Random r=new Random ();
		while(true) {
			int cdID=r.nextInt(10);
			int cdNum=r.nextInt(5)+1;
			CDSale cs=new CDSale();
			cs.ID=cdID;
			cdm.sale(cs, cdNum);
			try {
				this.sleep(r.nextInt(500));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
class ContrlThread extends Thread{
	CDManager cdm;

	public ContrlThread(CDManager cdm) {
		super();
		this.cdm = cdm;
	}
	public void run()
	{
		new InputThread(cdm).start();
		for(int i=0;i<2;i++) {
			new SaleThread(cdm).start();
		}
		try {
			this.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
public class CDManager {
	HashMap<Integer,CDSale> CDSList=new HashMap();
	void init() {
		for(int i=0;i<10;i++) {
			CDSale cs=new CDSale();
			cs.cdName="CD"+i;
			cs.ID=i;
			cs.num=10;
			CDSList.put(i, cs);
		}
	}
	public void sale(CDSale c,int num) {
		CDSale sc=CDSList.get(c.ID);
		sc.sale(num);
	}
	public void input() {
		for (CDSale cs:CDSList.values()) {
			cs.getin();
		}
	}
	
	public static void main(String[] arg) {
		CDManager cdm=new CDManager();
		cdm.init();
		Thread t=new ContrlThread(cdm);
		t.start();
				
	}
	

}
